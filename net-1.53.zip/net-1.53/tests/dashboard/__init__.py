"""Dashboard summary tests."""
