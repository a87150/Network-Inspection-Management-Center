"""Network-device collector tests."""
