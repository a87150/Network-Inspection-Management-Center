"""Security-device API tests."""
