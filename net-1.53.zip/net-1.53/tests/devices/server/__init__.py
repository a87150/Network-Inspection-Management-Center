"""Server collector tests."""
