"""Cross-device collection tests."""
