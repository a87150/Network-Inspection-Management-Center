"""Dashboard aggregation feature package."""
