"""Managed-device feature packages."""
