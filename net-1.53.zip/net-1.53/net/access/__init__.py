"""Access-control platform synchronization."""
