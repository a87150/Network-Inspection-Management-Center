# 架构与数据库结构

[返回项目首页](../README.md#架构与技术栈)

## 数据流与事务边界

1. 管理员提交表单，后端检查权限、CSRF、设备类型、参数和版本；保存配置后按本次所选设备/项目生成任务快照。
2. `Schedule` 到期时由 Worker 创建 `TaskRun` 和 `TaskTargetRun`；手动任务使用同一队列。没有 Worker 时，网页仍可访问，但定时任务不会入队、后台操作不会执行。
3. Worker 短事务领取任务并续租，在事务外完成 SSH、SNMP、HTTP、LDAP 等外部请求及耗时解析，最后重新检查租约/配置并短事务保存。PC 日志由 Web 写入 API 在短事务中接收。
4. 设备巡检保存动态记录和异常；可采集硬件资料按成功字段回填资产。PC API 接收日志后更新台账；手动和定时分析均在入队时为每台 PC 冻结最新日志；人员同步先获取完整预览，再事务应用。
5. 逐目标生成站内异常/恢复记录。整批任务终结且目标告警处理完成后，每渠道创建一条总结投递；网络发送在事务外完成，回写时校验投递租约。

**三种状态需要分开看**：任务执行状态（等待/运行/成功/部分成功/失败/取消）、所选项目的业务健康状态、消息投递状态。任务执行成功仍可能有 CPU 超限等业务异常；信息不足不代表设备故障；通知失败也不抹掉已保存的巡检结果。

数据库中的任务快照记录“入队时的范围和规则”，业务记录保存“当时的证据和结论”。新配置通常只影响新任务；历史结果不自动重算。人员/门禁/域控等外部数据操作还会核验实时配置，配置变更后拒绝应用旧结果。

## 数据库模型与关系

以 [模型定义](../net/models) 和 [迁移文件](../net/migrations) 为结构依据。下表是业务表索引，不是要求手动执行的建表 SQL。实际数据库是否已应用全部迁移，应运行 `python manage.py showmigrations net` 核实。

| 业务 | 模型及实际表名 | 关键字段与关系 |
| --- | --- | --- |
| 登录与授权 | Django `auth_user`、`auth_group`、`auth_permission` 及关系表 | 登录账号、staff/超级用户标记、后台模型权限；与业务人员独立 |
| 会话与迁移 | `django_session`、`django_migrations`、`django_content_type`、`django_admin_log` | 登录会话、已应用迁移、模型类型和后台操作日志 |
| 人员 | `People` → `net_people` | 工号 `employee_id` 唯一；姓名、部门、手机号、在职状态；`sync_source` 关联人员平台 |
| 人员平台 | `PeopleSyncSource` → `net_peoplesyncsource` | 唯一 `source_key`、凭据、根部门、启用状态；配置更新/连接测试/最近同步时间分别记录 |
| PC 台账 | `Computer` → `net_computer` | `computer_name` 唯一，保存基本资料和最近采集到的硬件信息 |
| 网络台账 | `Network_Device` → `net_network_device` | IP 唯一，厂商/类型、命令行（SSH/Telnet）与 SNMP 连接参数、硬件资料 |
| 服务器台账 | `Server` → `net_server` | IP 唯一，Linux/Windows 类型、SSH 或 HTTP 参数、系统和硬件资料 |
| 弱电台账 | `WeakCurrentDevice` → `net_weakcurrentdevice` | IP 唯一，摄像机/录像机/门禁/对讲/广播/打印机/温湿度计类型、厂商和连接参数 |
| 配置模板 | `DeviceCollectionTemplate` → `net_devicecollectiontemplate` | `kind + vendor + subtype + version_match` 唯一；`parent` 显式继承；`settings` 保存项目方法、命令、解析和报警规则 |
| 设备模板绑定 | `DeviceCollectionBinding` → `net_devicecollectionbinding` | `kind + target_id` 唯一；关联指定模板，保存 `overrides` 及加密协议凭据 |
| 巡检配置 | `InspectionProfile` → `net_inspectionprofile` | 设备类别、所选项目、目标选择器、超时/并发等；同类别配置名称唯一 |
| PC 分析配置 | `ComputerAnalysisProfile` → `net_computeranalysisprofile` | 唯一名称、人员/日志匹配模式、分析项目、软件规则和阈值 |
| 定时计划 | `Schedule` → `net_schedule` | 每行只关联一种巡检/PC 分析/人员来源/域控配置；间隔或每日时间、启用、下次执行、最近入队、最近调度尝试/状态/原因 |
| 主任务 | `TaskRun` → `net_taskrun` | 类型/来源、配置关联、规则/参数/目标快照、进度计数、租约/尝试次数、活动范围键 |
| 目标任务 | `TaskTargetRun` → `net_tasktargetrun` | 关联主任务；`task + target_type + target_id` 唯一；目标快照、执行状态、结果引用、告警处理状态、PC 分析交接子任务 |
| PC API 配置 | `PCUploadConfig` → `net_pcuploadconfig` | 单例配置；保存上传端点、启用状态、日志留存方式以及加密令牌和令牌哈希 |
| PC 日志 | `ComputerLogFile` → `net_computerlogfile` | 关联 PC，按上传 JSON 顶级属性分列保存平台、时间、系统、硬件、网络、软件、进程和策略状态；内容哈希用于去重 |
| PC 分析结果 | `ComputerAnalysis` → `net_computeranalysis` | 关联 PC、保存普通数值 `log_id`、分析配置/日期/来源时间、`exceptions` 唯一问题明细及可处理问题数投影；不复制完整日志，也不对日志建外键 |
| 设备巡检结果 | `Network_Device_Inspection` / `Server_Inspection` / `Monitor_Inspection` → `net_network_device_inspection` / `net_server_inspection` / `net_monitor_inspection` | 分别关联设备、服务器、安防资产及可选的一对一目标任务；状态、详情和指标 |
| 设备异常明细 | `Error_Network_Device` / `Error_Server` / `Error_Monitor` → 对应 `net_error_*` 表 | 关联所属设备巡检记录；PC 问题只保存在 `ComputerAnalysis.exceptions`，避免重复；业务问题不与任务执行失败混为一张表 |
| 原始配置备份 | `DeviceConfigurationBackup` → `net_deviceconfigurationbackup` | `device_type + device_id + backup_date` 唯一；原文密文、SHA-256、大小、采集时间及目标任务引用 |
| AD 本地对象 | `Domain_Account` / `Domain_Computer` / `Domain_Group` → `net_domain_account` / `net_domain_computer` / `net_domain_group` | AD object GUID 唯一，保存账号、计算机、分组及 DN 等本地快照 |
| AD 成员与 OU | `DomainMembership` / `DomainOU` → `net_domainmembership` / `net_domainou` | 成员关联分组和一个账户或计算机，区分主组；OU 保存包括空 OU 的可选目录。账户/计算机的分组名称缓存用于数据库筛选、排序和导出 |
| AD 配置与写操作 | `Domain_Controller_Config` / `DomainOperation` / `DomainOperationSecret` → `net_domain_controller_config` / `net_domainoperation` / `net_domainoperationsecret` | 目录连接设置；操作记录关联申请账号和任务；密码载荷单独加密存储 |
| 门禁平台与记录 | `AccessRecordSource` / `AccessRecord` → `net_accessrecordsource` / `net_accessrecord` | 来源可关联弱电设备；平台游标、加密令牌；`source + source_event_id` 唯一，保存时间/人员/门点/方向/结果 |
| 项目等级 | `IssueSeverityPolicy` → `net_issueseveritypolicy` | 按项目保存等级覆盖；设备模板可进一步提供项目阈值和等级 |
| 告警配置 | `AlertChannel` / `AlertPolicy` / `AlertNotificationTemplate` → `net_alertchannel` / `net_alertpolicy` / `net_alertnotificationtemplate` | 渠道、默认/项目路由策略与任务总结样式；策略与渠道为多对多 |
| 告警状态与事件 | `AlertState` / `AlertEvent` → `net_alertstate` / `net_alertevent` | 按配置、目标和问题键追踪异常/恢复；事件关联任务/目标；每任务总结由唯一 `summary_task` 保证 |
| 告警投递与测试 | `AlertDelivery` / `AlertTestSend` → `net_alertdelivery` / `net_alerttestsend` | 事件与渠道组合唯一，保存尝试次数、租约、响应摘要；渠道测试另行记录 |

核心关系如下，图中省略了设备类型分表、可空的历史引用以及 Django 自带表：

```mermaid
flowchart TD
    Schedule[定时计划] --> Task[TaskRun 主任务]
    Profile[巡检或分析配置] --> Task
    Task --> Target[TaskTargetRun 目标]
    Target --> Result[巡检或分析记录]
    Asset[资产基本资料] --> Result
    Api[PC API 上报] --> Log[原始日志]
    Log -. 普通 log_id .-> Analysis[PC 分析记录]
    Target --> Analysis
    Result --> Errors[异常明细]
    Task --> Event[站内事件 / 任务总结]
    Event --> Delivery[告警投递]
    Channel[渠道] --> Delivery
    Template[配置模板及父模板] --> Binding[设备绑定与覆盖]
    Binding -. 入队解析并冻结 .-> Target
```

**查询字段**：动态记录维护 `report_metrics`、`report_problem_types`、`report_severity`、`report_enrichment` 等报告字段，方便数据库分页、筛选和统计；修改原始详情的维护脚本还须同步更新这些字段。直接 SQL 或绕过保存逻辑的批量更新可能造成页面与证据不一致。

**关系字段与 JSON 的分工**：资产、任务、来源、时间、状态及常用查询字段使用关系字段和索引；异构回显、详情、规则和快照使用 JSON。`TaskTargetRun.result_snapshot` 的新版格式主要保存结果引用和摘要，详情从对应业务记录读取，不应把所有历史 JSON 载入内存再分页。`DeviceCollectionBinding.target_id`、备份的 `device_id`、任务的 `target_id` 是带类型的业务引用，并非每种资产表都有一个数据库外键；不要据此手工删除关联对象。

**去重与并发**：日志内容哈希用于避免重复上报；daily_latest 按每台 PC 的日志日期保留最新版本；任务 `active_scope_key` 唯一约束控制相同范围的活动任务，目标还有执行范围互斥。门禁用平台事件 ID 去重，配置备份按设备和日期去重，任务总结及渠道投递各自有唯一约束。它们分别解决不同边界，不能把一次失败重试简单替换为删除历史记录。

**MariaDB 特别说明**：模型声明的条件唯一约束不等于数据库一定直接支持。`0040_mariadb_active_target_scope` 为目标执行范围添加了生成列 `net_active_execution_scope` 和唯一索引 `net_target_active_scope_mysql`，补足 MariaDB/MySQL 上的对应约束；不要只因 `models.W036` 就认定没有防重，也不要只屏蔽警告而忽略迁移。域分组 DN 的长字段唯一性会触发 `mysql.W003`，须在目标数据库核实索引能力和迁移结果，不能擅自截断 DN 或重置表。

维护时应备份数据库、环境配置和独立密钥。`migrate` 更新结构；`makemigrations --check --dry-run` 只检查模型漂移；`showmigrations` 检查应用状态。不要把 ORM 模型自动序列化结果当成包含全部凭据及原始证据的完整备份。

---

本项目保留两个 Django 应用：`net` 负责数据、业务和外部连接，`index`
负责页面、表单、模板与 URL。业务代码只使用下列规范路径，不再维护旧模块别名。

## 后端

- `net/models/`：人员、域控、设备、记录、任务、报警和集成配置模型。
- `net/people/`：人员导入、目录适配、同步和后台执行。
- `net/domain/`：域控连接、同步、密钥、批量操作和任务执行。
- `net/devices/`：PC、服务器、网络设备和弱电设备的采集与解析。
- `net/inspections/`：任务队列、调度、Worker、巡检执行和记录汇总。
- `net/alerts/`：报警策略、消息、飞书、钉钉和邮件发送。
- `net/data_exchange/`：CSV 与设备配置导入导出。
- `net/infrastructure/`：通用 SSH、HTTP、采集结果和脱敏工具。
- `net/devices/pc/`：PC API 上报、日志入库、留存、分析及终端数据解析。
- `net/scripts/`：页面下载的 Windows/macOS PC 采集脚本模板与生成器。

## 页面与静态资源

`index/` 按 `dashboard`、`people`、`domain`、`devices`、`inspections`、
`alerts` 和 `common` 分类。模板使用相同目录名。业务静态资源位于
`static/app/`，Bootstrap 位于 `static/vendor/bootstrap/`；`staticfiles/`
是 `collectstatic` 生成目录，不应手工编辑或提交。

## 采集端、部署和测试

- `agents/pc/windows/`：PC 信息采集脚本及其 DLL。
- `agents/server/windows/`：Windows 服务器巡检 HTTP 服务与安装脚本。
- `deploy/windows/`：Windows Web/Worker 服务示例。
- `deploy/linux/systemd/`：Linux systemd 双服务示例。
- `tests/`：按业务域组织的 Django、前端和 PowerShell 测试。
- `config/examples/`：不含凭据的配置格式示例。
- `tools/`：不参与 Django 启动的独立运维客户端。

新增设备采集器时放入对应 `net/devices/<类型>/`，通用协议能力放入
`net/infrastructure/`；新增页面放入对应 `index/<类型>/` 并在
`index/urls.py` 注册；新增后台任务放入 `net/inspections/`；新增测试放入
匹配的 `tests/<类型>/`；新增终端脚本放入 `agents/` 的对应平台目录。

运行数据库、终端本地日志、生成配置、`demo-runtime/`、`.venv/`、
`.worktrees/` 和 `staticfiles/` 都是运行或生成数据，不参与源码整理。