"""Managed-device UI packages."""
